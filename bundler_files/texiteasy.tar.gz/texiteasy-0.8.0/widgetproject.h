#ifndef WIDGETPROJECT_H
#define WIDGETPROJECT_H

#include <QWidget>

class WidgetProject : public QWidget
{
    Q_OBJECT
public:
    explicit WidgetProject(QWidget *parent = 0);

signals:

public slots:

};

#endif // WIDGETPROJECT_H
