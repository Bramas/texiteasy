#include "widgetproject.h"

WidgetProject::WidgetProject(QWidget *parent) :
    QWidget(parent)
{
    this->setStyleSheet("background-color:#ff0000");
}
